document.addEventListener("DOMContentLoaded", function () {
    // 获取页面上的各个元素
    const productList = document.querySelector(".products"); // 产品列表
    const paginationList = document.getElementById("pagination-list"); // 分页列表
    const searchInput = document.getElementById("search"); // 搜索输入框
    const priceFilter = document.getElementById("price-filter"); // 价格筛选
    const sortSelect = document.getElementById("sort"); // 排序下拉框

    const productsPerPage = 3; // 每页显示的产品数量
    const products = Array.from(productList.getElementsByClassName("product")); // 获取所有产品元素
    let totalPages = Math.ceil(products.length / productsPerPage); // 总页数
    let currentPage = 1; // 当前页数

    // 显示特定页的产品
    function showPage(page) {
        for (let i = 0; i < products.length; i++) {
            products[i].style.display = "none";
        }

        for (let i = (page - 1) * productsPerPage; i < page * productsPerPage; i++) {
            if (products[i]) {
                products[i].style.display = "block";
            }
        }
    }

    // 创建分页链接
    function createPaginationLinks() {
        for (let i = 1; i <= totalPages; i++) {
            const li = document.createElement("li");
            const link = document.createElement("a");
            link.href = "#";
            link.classList.add("page-link");
            link.textContent = i;

            link.addEventListener("click", function (event) {
                event.preventDefault();
                currentPage = i;
                showPage(currentPage);

                // 移除其他链接的 'active' 类
                const links = paginationList.getElementsByClassName("page-link");
                for (let j = 0; j < links.length; j++) {
                    links[j].classList.remove("active");
                }

                // 为当前链接添加 'active' 类
                link.classList.add("active");
            });

            li.appendChild(link);
            paginationList.appendChild(li);
        }
    }

    // 过滤和排序产品
    function filterAndSortProducts() {
        const searchText = searchInput.value.toLowerCase();
        const filterValue = priceFilter.value;
        const sortValue = sortSelect.value;

        const filteredProducts = products.filter((product) => {
            const name = product.getAttribute("data-name").toLowerCase();
            const price = parseInt(product.getAttribute("data-price"));

            const nameMatch = name.includes(searchText);
            const priceMatch =
                filterValue === "all" ||
                (filterValue === "under-25" && price <= 25) ||
                (filterValue === "over-25" && price > 25);

            return nameMatch && priceMatch;
        });

       
        // 根据排序选项排序产品
if (sortValue == "low-to-high") {
    filteredProducts.sort((a, b) => {
        // 从价格属性中去除 "$" 符号并转换为整数
        const priceA = parseInt(a.getAttribute("data-price").replace("$", ""));
        const priceB = parseInt(b.getAttribute("data-price").replace("$", ""));
        return priceA - priceB;
    });
} else if (sortValue == "high-to-low") {
    filteredProducts.sort((a, b) => {
        // 从价格属性中去除 "$" 符号并转换为整数
        const priceA = parseInt(a.getAttribute("data-price").replace("$", ""));
        const priceB = parseInt(b.getAttribute("data-price").replace("$", ""));
        return priceB - priceA;
    });
}


        // 隐藏所有产品
        for (let i = 0; i < products.length; i++) {
            products[i].style.display = "none";
        }
 // 显示过滤和排序后的产品
 for (let i = 0; i < filteredProducts.length && i < productsPerPage; i++) {
    filteredProducts[i].style.display = "block";
}

        totalPages = Math.ceil(filteredProducts.length / productsPerPage);
        currentPage = 1;
        paginationList.innerHTML = "";
        createPaginationLinks();
    }









    function sortProducts() {
        const products = Array.from(productList.getElementsByTagName("div"));

        products.sort(function (a, b) {
            const priceA = parseFloat(a.getAttribute("data-price"));
            const priceB = parseFloat(b.getAttribute("data-price"));

            if (sortSelect.value === "low-to-high") {
                return priceA - priceB;
            } else if (sortSelect.value === "high-to-low") {
                return priceB - priceA;
            }
        });

        products.forEach(function (product) {
            productList.appendChild(product);
        });
    }

    sortSelect.addEventListener("change", sortProducts);










    // 监听搜索输入、价格筛选和排序的改变
    searchInput.addEventListener("input", filterAndSortProducts);
    priceFilter.addEventListener("change", filterAndSortProducts);
    sortSelect.addEventListener("change", filterAndSortProducts);

    // 初始化页面，创建分页链接并显示第一页的产品
    createPaginationLinks();
    showPage(currentPage);
});