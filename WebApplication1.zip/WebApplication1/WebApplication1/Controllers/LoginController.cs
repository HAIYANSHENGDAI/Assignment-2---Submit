﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApplication1.Models;
namespace WebApplication1.Controllers
{
    public class LoginController : Controller
    { //数据库访问对象
        private ShoppingTest db=new ShoppingTest();
        // GET: Login
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult indexback()
        {
            return View();
        }

        [HttpPost]
        public ActionResult indexback( string username,string pwd)
        {
            if (string.IsNullOrEmpty(username)) {

                ViewBag.error = "User name  cannot be empty";


              }
            else if (string.IsNullOrEmpty(pwd))
            {

                ViewBag.error = " password cannot be empty";


            }
            else
            {

                user u = db.user.FirstOrDefault(p => p.username == username && p.pwd == pwd);
                if(u==null)
            {
                ViewBag.error = "User name and password is wrong";
            }
                else
                {
                    return Redirect("/main/index");
                }
            }
           

            return View();
        }




        [HttpGet]
        public ActionResult Register()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Register(string username, string pwd)
        {
            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(pwd))
            {
                ViewBag.error = "User name and password cannot be empty";
            }
            else
            {
                user newUser = new user
                {
                    username = username,
                    pwd = pwd,
                    nickname = "y",
                   power=1
                };

                // 将新用户添加到数据库
                db.user.Add(newUser);

                // 保存更改到数据库
                db.SaveChanges();

                return RedirectToAction("indexback"); // 或者重定向到登录页面
            }

            return View();
        }

    }
}