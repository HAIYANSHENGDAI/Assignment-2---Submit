﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebApplication1.Controllers
{
    public class mainController : Controller
    {
        // GET: main
        public ActionResult index()
        {
            return View();
        }
        public ActionResult about()
        {
            return View();
        }
        public ActionResult product()
        {
            return View();
        }
    }
}