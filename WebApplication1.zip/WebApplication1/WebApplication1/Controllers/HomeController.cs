﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApplication1.Models;
using WebApplication1.Models;
namespace WebApplication1.Controllers
{
    public class HomeController : Controller
    {//操作数据库上下文对象
        private ShoppingTest db = new ShoppingTest();

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }

        //展示用户列表
        public ActionResult UserList()
        {
            //获取用户列表展示
            ViewBag.ulist = db.user.ToList();
            return View();
        }

    }
}